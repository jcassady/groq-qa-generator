
import streamlit as st
import os

# Import the necessary function from groq_qa_generator
from groq_qa_generator import configure_and_generate_qa_pairs

# Load the sample text (sample_input_data.txt)
sample_file_path = os.path.join(os.path.dirname(__file__), '..', 'groq_qa_generator', 'prompts', 'sample_input_data.txt')
with open(sample_file_path, 'r') as f:
    book_content = f.read()

# Title of the web app
st.title("Groq QA Generator - Interactive Book & Chat")

# Create two columns: left for book content, right for QA chat
col1, col2 = st.columns([2, 1])

# Display book content in the left column
with col1:
    st.markdown("<div style='padding: 20px; background-color: #f9f9f9; border-radius: 10px;'>", unsafe_allow_html=True)
    st.text_area("Book Content", book_content, height=400)
    st.markdown("</div>", unsafe_allow_html=True)

# Chat UI for the generated questions and answers in the right column
with col2:
    st.markdown("<div style='padding: 20px; background-color: #333; border-radius: 10px;'>", unsafe_allow_html=True)
    
    # Placeholder for question-answer generation (for now it's a mockup)
    st.markdown("<h3 style='color: white;'>Question:</h3>", unsafe_allow_html=True)
    st.markdown("<div style='color: white; padding: 10px; background-color: #444; border-radius: 5px;'>What is the theme of this book?</div>", unsafe_allow_html=True)
    
    st.markdown("<h3 style='color: white;'>Answer:</h3>", unsafe_allow_html=True)
    st.markdown("<div style='color: white; padding: 10px; background-color: #555; border-radius: 5px;'>The main theme revolves around curiosity and wonder.</div>", unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)

# Add button to generate new Q&A (Mockup)
if st.button("Generate New Question-Answer"):
    # Placeholder for actual QA generation using configure_and_generate_qa_pairs
    st.write("New question-answer pair would appear here.")
