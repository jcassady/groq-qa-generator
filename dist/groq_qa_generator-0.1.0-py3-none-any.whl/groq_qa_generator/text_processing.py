import re
import json
import logging
import os


def clean_text(text):
    """Cleans the input text by removing excessive whitespace.

    This function replaces all sequences of whitespace characters (including tabs,
    newlines, and multiple spaces) with a single space. It also trims any leading
    or trailing whitespace from the text.

    Args:
        text (str): The input text to be cleaned.

    Returns:
        str: The cleaned text with excessive whitespace removed and leading/trailing
             whitespace trimmed.
    """
    return re.sub(r"\s+", " ", text).strip()


def write_response_to_file(response, output_file, json_format=False):
    """Write the generated response to the specified output file.

    This function writes the accumulated response to the output file in either JSON or plain text format,
    and logs the output.

    Args:
        response (str): The response string to be written to the file.
        output_file (str): The base name for the output file (without extension).
        json_format (bool): Flag to indicate whether to write as JSON. Defaults to False.

    Side Effects:
        Writes the response to the specified output file and flushes the file buffer.
    """
    # If json_format is True, prepare the path for the JSON file
    if json_format:
        json_file_path = output_file.replace(".txt", ".json")

        response_data = []

        # Load existing data if the JSON file already exists
        if os.path.exists(json_file_path):
            with open(json_file_path, "r", encoding="utf-8") as json_file:
                try:
                    # Attempt to load existing JSON data
                    response_data = json.load(json_file)
                except json.JSONDecodeError:
                    # Log a warning if there's a JSON decode error
                    logging.warning(
                        f"JSON decode error in {json_file_path}, starting fresh."
                    )
                    response_data = []

        logging.info(response)  # Log the response being processed

        # Split the response into individual QA pairs based on double new lines
        qa_pairs = response.strip().split("\n\n")
        for qa in qa_pairs:
            if "\n" in qa:
                # Split each QA pair into question and answer
                question, answer = qa.split("\n", 1)
                # Append the QA pair to the response data list
                response_data.append(
                    {"question": question.strip(), "answer": answer.strip()}
                )
            else:
                # Log a warning for malformed QA pairs
                logging.warning(f"Malformed QA pair found: {qa}")

        # Write the collected QA pairs to the JSON file
        with open(json_file_path, "w", encoding="utf-8") as json_file:
            json.dump(response_data, json_file, ensure_ascii=False, indent=4)
    else:
        # Prepare the path for the plain text output file
        text_file_path = output_file

        existing_qa_pairs = []

        # Load existing QA pairs from the text file if it exists
        if os.path.exists(text_file_path):
            with open(text_file_path, "r", encoding="utf-8") as text_file:
                existing_qa_pairs = text_file.read().strip().split("\n\n")

        # Split the response into individual QA pairs
        qa_pairs = response.strip().split("\n\n")
        for qa in qa_pairs:
            if "\n" in qa:
                # Split each QA pair into question and answer
                question, answer = qa.split("\n", 1)
                # Append the QA pair to the existing pairs list
                existing_qa_pairs.append(f"{question.strip()}\n{answer.strip()}")
            else:
                # Log a warning for malformed QA pairs
                logging.warning(f"Malformed QA pair found: {qa}")

        # Write all QA pairs (existing + new) to the text file
        with open(text_file_path, "w", encoding="utf-8") as text_file:
            for qa in existing_qa_pairs:
                text_file.write(qa + "\n\n")
