import os
import argparse
import json
import shutil
import logging


def parse_arguments():
    parser = argparse.ArgumentParser(description="Generate QA pairs from text input.")
    parser.add_argument(
        "--json",
        action="store_true",
        help="Save QA pairs as JSON instead of plain text.",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="llama3-70b-8192",  # You can set a default model here
        help="Specify the model to be used for generating QA pairs.",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.7,  # You can set a default temperature here
        help="Set the temperature for the model's output generation.",
    )
    return parser.parse_args()


def load_config(config_file="config.json"):
    # Define the user's configuration directory
    user_config_dir = os.path.expanduser("~/.groq_qa/")
    config_file_path = os.path.join(user_config_dir, config_file)

    # Check if the config file exists
    if not os.path.exists(config_file_path):
        raise FileNotFoundError(f"Config file not found: {config_file_path}")

    # Load the configuration file
    with open(config_file_path, "r") as f:
        config = json.load(f)

    # Resolve paths to be relative to the user config directory
    # Update the paths to include the prompts directory
    config["system_prompt"] = os.path.join(
        user_config_dir, "data", "prompts", config["system_prompt"]
    )
    config["sample_question"] = os.path.join(
        user_config_dir, "data", "prompts", config["sample_question"]
    )
    config["input_data"] = os.path.join(user_config_dir, "data", config["input_data"])
    config["output_file"] = os.path.join(user_config_dir, config["output_file"])

    # Override config values if CLI arguments are provided
    if args.model:
        config["model"] = args.model
    if args.temperature is not None:
        config["temperature"] = args.temperature
    if args.json:
        base_output_file = os.path.splitext(config["output_file"])[0]
        config["output_file"] = f"{base_output_file}.json"


    # Log the loaded configuration
    log_config(config, config_file_path)  # Pass the config file path

    return config


def log_config(config, config_file_path):
    max_key_length = max(len(key) for key in config.keys()) + 2  # Add padding
    header = f"{'Configuration Key'.ljust(max_key_length)} | Value"
    separator = "-" * len(header)

    logging.info("")
    logging.info(f"Config file path: {config_file_path}")  # Log the config file path
    logging.info(header)
    logging.info(separator)

    for key, value in config.items():
        logging.info(f"{key.ljust(max_key_length)} | {value}")
    logging.info("")


def setup_user_config_dir():
    """
    Ensure that the user-specific configuration directory and files exist.

    Creates the user directory (~/.groq_qa/) if it doesn't exist, and copies default
    files from the package directory to the user directory if they are missing.
    """
    # Define user-specific directory
    user_config_dir = os.path.expanduser("~/.groq_qa/")
    os.makedirs(user_config_dir, exist_ok=True)
    logging.debug(f"User configuration directory created: {user_config_dir}")

    # Correctly get the path to the data directory in the package
    package_data_path = os.path.join(os.path.dirname(__file__), "data")
    logging.debug(f"Package data path: {package_data_path}")

    # Copy the entire data folder to the user config directory
    dest_data_path = os.path.join(user_config_dir, "data")
    logging.debug(f"Destination data path: {dest_data_path}")

    if os.path.exists(dest_data_path):
        logging.debug(
            f"Data directory already exists at: {dest_data_path}. Skipping copy."
        )
    else:
        shutil.copytree(package_data_path, dest_data_path)
        logging.debug(
            f"Copied data directory from {package_data_path} to {dest_data_path}"
        )

    # Copy the prompts folder specifically (now directly under data)
    package_prompts_path = os.path.join(package_data_path, "prompts")

    dest_prompts_path = os.path.join(dest_data_path, "prompts")

    if os.path.exists(dest_prompts_path):
        logging.debug(
            f"Prompts directory already exists at: {dest_prompts_path}. Skipping copy."
        )
    else:
        shutil.copytree(package_prompts_path, dest_prompts_path)
        logging.debug(
            f"Copied prompts directory from {package_prompts_path} to {dest_prompts_path}"
        )

    # Copy the config.json file if it doesn't exist
    config_src_path = os.path.join(os.path.dirname(__file__), "config.json")

    config_dest_path = os.path.join(user_config_dir, "config.json")

    if os.path.exists(config_dest_path):
        logging.debug(
            f"Config file already exists at: {config_dest_path}. Skipping copy."
        )
    else:
        shutil.copy(config_src_path, config_dest_path)
        logging.debug(f"Copied config.json from {config_src_path} to {config_dest_path}")


args = parse_arguments()
