from groq_qa_generator.logging_setup import setup_logging
from groq_qa_generator.config import load_config, setup_user_config_dir
from groq_qa_generator.tokenizer import read_and_chunk_text
from groq_qa_generator.qa_generation import generate_qa_pairs


def main():
    """Main entry point for the QA pair generation process.

    This function orchestrates the entire process of setting up logging,
    initializing the user configuration directory, loading the configuration,
    reading and chunking the input text, and generating question-answer pairs.
    """
    setup_logging()  # Initialize logging for the application.

    setup_user_config_dir()  # Create and set up user configuration directory and files.

    groq_config = load_config()  # Load configuration settings from the config file.

    text_chunks = read_and_chunk_text(
        groq_config["input_data"], chunk_size=groq_config.get("chunk_size", 512)
    )  # Read input data and chunk it into manageable pieces.

    qa_pairs = generate_qa_pairs(text_chunks, groq_config)  # Generate question-answer pairs from text chunks.


if __name__ == "__main__":
    main()  # Run the main function if the script is executed directly.
