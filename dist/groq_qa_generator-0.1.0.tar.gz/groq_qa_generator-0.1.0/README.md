# GroQ QA Generator for LLM Fine-Tuning

This project generates question-and-answer pairs (QA pairs) based on the provided text using the Groq API and LLM models, such as Llama3. The generated QA pairs are intended to be used for fine-tuning language models. This script utilizes the GroQ API to generate relevant QA pairs with contextual understanding.

## Features

- Generates diverse QA pairs based on the provided text.
- Handles chunking of text to fit model input size constraints.
- Customizable system prompts for training and testing.
- Outputs QA pairs in a structured text file for easy use in fine-tuning models.
- Uses the GroQ API for completion generation, with built-in error handling and logging.

## Requirements

- Python 3.7 or higher
- Poetry (for managing dependencies)

## Installation

1. **Clone the repository**:

   ```bash
   git clone https://github.com/jcassady/groq-qa-generator.git
   cd groq-qa-generator
